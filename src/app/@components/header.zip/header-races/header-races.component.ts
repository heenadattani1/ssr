import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-header-races',
  templateUrl: './header-races.component.html',
  styleUrls: ['./header-races.component.scss'],
})
export class HeaderRacesComponent implements OnInit {
  @Input() regionEvents;
  @Input() device: string;
  @Output() closeDropDown = new EventEmitter();
  constructor() {}

  ngOnInit(): void {
    this.regionEvents = Array.isArray(this.regionEvents) ? this.regionEvents : [];
  }
  closeDropdown() {
    this.closeDropDown.next({ raceName: 'Races' });
  }
}
