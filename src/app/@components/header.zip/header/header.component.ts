import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { VirtualChallengeSharedDataService } from '@core/utils/virtual-challenge-shared-data.service';
import { NgbDropdown, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { localStorageConstant, LocalStorageService, RACE_CONFIG } from '@core/utils';
import { CommonModelDialogComponent } from '@components/virtual-challenge/common-model-dialog/common-model-dialog.component';
import { ActivatedRoute, Router, RouterEvent, NavigationEnd } from '@angular/router';
import { authRoutes, virtualChallengeRoutes, headerRoutes, registrationRoutes } from '@core/utils/routes-path.constant.service';
import { RagnarCMSDataService, RCMSEventDataService } from '@core/data';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';
import { TranslateService } from '@ngx-translate/core';
import { DashboardBehviourSubject } from '@core/interfaces/virtual-challenge.interface';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  @ViewChildren(NgbDropdown) dropdowns: QueryList<NgbDropdown>;
  public authRoutes = authRoutes;
  public virtualChallengeRoutes = virtualChallengeRoutes;
  public headerRoutes = headerRoutes;

  public virtualChallengeNav: DashboardBehviourSubject[] = [
    {
      label: 'Dashboard',
      value: 'dashboard',
    },
    {
      label: 'Leaderboard',
      value: 'leaderBoard',
    },
    {
      label: 'Invite',
      value: 'invite',
    },
    {
      label: 'Add Run',
      value: 'addRun',
    },
    {
      label: 'Activity Feed',
      value: 'activityFeed',
    },
  ];

  public selectedVirtualChallengeNav = 'Dashboard';

  public userData = null;

  public show = {
    virtualNav: false,
    profileOption: false,
    mobileNav: false,
  };

  public regions = RACE_CONFIG.regions;

  public virtualChallengeNotifications;

  public virtualChallengePeriod = 'REGISTER';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private modalService: NgbModal,
    private localStorageService: LocalStorageService,
    private virtualChallengeSharedDataService: VirtualChallengeSharedDataService,
    private ragnarCmsDataService: RagnarCMSDataService,
    private translate: TranslateService,
    private rcmsEventDataService: RCMSEventDataService,
  ) {}

  ngOnInit(): void {
    const clonedVirtualChallengeNav = _.cloneDeep(this.virtualChallengeNav);
    this.virtualChallengeSharedDataService.getDashboardMenu().subscribe((response: DashboardBehviourSubject) => {
      if (response && response.exclude) {
        this.virtualChallengeNav = this.virtualChallengeNav.filter((menu) => response.exclude !== menu.value);
      } else if (response) {
        this.virtualChallengeNav = response as DashboardBehviourSubject[];
      } else {
        this.virtualChallengeNav = clonedVirtualChallengeNav;
      }
    });

    this.virtualChallengeSharedDataService.getUserData().subscribe((response) => {
      if (response) {
        this.setUserData();
      }
    });

    this.route.fragment.subscribe((fragment: string) => {
      this.show.virtualNav = this.router.url.includes(`/${virtualChallengeRoutes.dashboard}`);
      if (fragment && this.show.virtualNav) {
        this.selectedVirtualChallengeNav = this.virtualChallengeNav.find((menu) => menu.value === fragment).label;
      }
    });

    this.router.events.subscribe((event: RouterEvent) => {
      if (event instanceof NavigationEnd) {
        this.show.virtualNav = this.router.url.includes(`/${virtualChallengeRoutes.dashboard}`);
      }
    });

    this.virtualChallengeSharedDataService.getNotifications().subscribe((response) => {
      if (response) {
        this.virtualChallengeNotifications = response;
      }
    });

    this.setUserData();
    this.getRaces();
    this.setVirtualChallengePeriod();
    this.translate.setDefaultLang('en');
  }

  onDashboardScreenChange(screenName: string) {
    window.location.hash = screenName;
  }

  setUserData() {
    this.userData = this.localStorageService.getUser();
  }

  logout() {
    this.localStorageService.flushAll();
    this.userData = null;
    this.rcmsEventDataService.clearUserEventCache();
    this.virtualChallengeNotifications = [];
    this.router.navigate([`/`]);
  }

  showNotifications() {
    const modalRef = this.modalService.open(CommonModelDialogComponent, {
      scrollable: true,
      centered: true,
      keyboard: false,
      backdrop: 'static',
      windowClass: 'notification_head',
    });

    modalRef.componentInstance.componentData = {
      type: 'notification',
      title: 'Notifications',
      notificationsData: this.virtualChallengeNotifications,
    };
  }

  getRaces() {
    this.ragnarCmsDataService.getRaces().subscribe((events) => {
      Object.keys(RACE_CONFIG.regions).forEach((regionKey) => {
        this.regions[regionKey] = _.chain(events.data.fetchRaceList)
          .filter({ region: RACE_CONFIG.regions[regionKey] })
          .orderBy(['coming_soon', 'start_date'])
          .value();
      });
    });
  }

  redirectToURL(url, routeFlag) {
    this.show.mobileNav = false;
    routeFlag ? this.router.navigateByUrl(`/${url}`) : window.open(url, '_blank');
  }

  setVirtualChallengePeriod() {
    // TODO: VC2-119
    setInterval(() => {
      const today = moment(moment.tz(moment().utc(false), 'America/Denver').format('YYYY-MM-DDTHH:mm:ss') + '.000Z').utc();
      const register = moment('2021-12-15 00:00:01', 'YYYY-MM-DD HH:mm:ss');
      const finished = moment('2022-01-31 23:59:58', 'YYYY-MM-DD HH:mm:ss');
      if (today.isAfter(register)) {
        this.virtualChallengePeriod = 'STARTED';
      }

      if (today.isAfter(finished)) {
        this.virtualChallengePeriod = 'FINISHED';
      }
    }, 1000);
  }

  closeDropDown(event) {
    if (event) {
      this.dropdowns.toArray().forEach((el) => {
        el.close();
      });
    }
    this.show.mobileNav = false;
  }
  loginWithRedirection() {
    const isRediretToVC = window.location.pathname === '/challenge/info' && window.location.href?.split('?')[1]?.includes('challengeId');
    const params = window.location.href?.split('?')[1]?.split('&');
    if (params) {
      const challengeId = params[0]?.split('=')[1];
      const challengeTeamId = params[1]?.split('=')[1];
      if (isRediretToVC) {
        this.localStorageService.set(
          localStorageConstant.redirectTo,
          `/${authRoutes.main}/${registrationRoutes.main}/${registrationRoutes.virtualChallenge}/${challengeId}/${registrationRoutes.personalInfo}`,
        );
        this.localStorageService.set('challengeTeamId', challengeTeamId);
      }
    }

    this.router.navigate([`/${this.authRoutes.main}/${this.authRoutes.login}`]);
  }
}
